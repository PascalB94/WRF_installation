#!/bin/bash
##########################################
# Suggestions for the case, if errors happen
#-----------------------------------------
#Since there are different versions, which can be installed by this script, there are cases, where the script has to be edited.
#Suggestion: try the script with the version, you want to install and if errors happen, think about if one of the following points could be the problem:
#1) The commands to untar the input tar files could produce a directory structure that can't be used for the next installation steps. After untaring, there should be only a WRF and a WPS directory in your project directory. If this does not happen, edit the untar commands.
#2) The environment commands, such as 'module load ...' and 'export ...' could be chosen uncorrectly for the installation of your version, especially, if you find 'undefined refences' in the compiling log file. Proof, if the 'export NETCDF_classic=1' command is needed or not.
#3) When compiling WPS, the compiler wants to use scripts in the WRF dirctory. Usually, the compiler 'thinks', the name of the WRF directory is 'WRF3', even in version 4.0. But it's possible, that it wants another name of the WRF directory. In this case, change the move and back move commands for the WRF directory which change its name.
#*) If there are any other error cases while the installation, please add them as new points. 
##########################################
#Parameters
user=backes1 #user name on platform = name of your project directory
project=test #directory, which should be created for the project, where wrfrun should be run
version=4.1 #version of WRF
#xversion=4 #only the number before the first point
platform=JURECA #JURECA, JUCEDA, ...
WRFPATH=/p/project/cjicg21/backes1/test/WRF-4.1.tar.gz #Path, where the WRF...tar file is
WPSPATH=/p/project/cjicg21/backes1/test/WPS-4.1.tar.gz #Path, where the WPS...tar file is
userdirectory=/p/project/cjicg21/backes1 #directory, where the installation starts from
scratchdir=/p/scratch/cjicg21/backes1 #directory, where the results of WRF forecasts (wrfout, geogrid, ...) and MARS data should be saved
##########################################
##########################################
echo Installation of WRF version starts!
echo ' '
if [ ! -d "$project" ]; then 
    mkdir $project && echo Make directory "'$project'".
fi
if [[ $WRFPATH == *"tar.gz"* ]]; then
    zip=yes
else
    zip=no
fi
cd $project
echo ' '
echo Date: 
date
echo ' '
echo Current directory:
pwd
echo ' '
WRFdir=WRFV$version
if [[ ! -d "$WRFdir" ]]; then
    mkdir $WRFdir
fi
cd $WRFdir
cp $WRFPATH ./
if [[ ! -d "main" ]]; then #proof, if WRF is untared by checking, if there is the "main" directory
    echo Untar WRF and WPS
    if [ $zip == no ]; then
	tar -C ./ -xf $WRFPATH
    else
	tar -xzf $WRFPATH
    fi
fi
if [[ ! -d "main" ]]; then #if not,a new directory was created. So the content has to be copied to WPSdir
    cp -R *WRF*/* ./
    rm -R *WRF*
fi
cd ..
WPSdir=WPSV$version
if [[ ! -d "$WPSdir" ]]; then
    mkdir $WPSdir
fi
cd $WPSdir
cp $WPSPATH ./
if [[ ! -d "geogrid" ]]; then #proof, if WPS is untared by checking, if there is the "geogrid" director; and then extract (gzip ot tar)
    if [ $zip == no ]; then
	tar -C ./ -xf $WPSPATH
    else
	tar -xzf $WPSPATH
    fi
    echo Untared WRF and WPS.
fi
if [[ ! -d "geogrid" ]]; then # if not,a new directory was created. So the content has to be copied to WPSdir
    cp -R *WPS*/* ./
    rm -R *WPS*
fi
if [[ ! -d "LIBRARIES" ]]; then
    mkdir LIBRARIES
fi
cd LIBRARIES
echo Directories in "LIBRARY":
ls
echo Download Libraries mpich-3.0.4, netcdf-4.1.3, JasPer-1.900.1, libpng-1.2.50 and zlib-1.2.7, if not there.
if [ ! -f "netcdf-4.1.3.tar.gz" ]; then
    wget http://www2.mmm.ucar.edu/wrf/OnLineTutorial/compile_tutorial/tar_files/netcdf-4.1.3.tar.gz
fi
if [ ! -f "mpich-3.0.4.tar.gz" ]; then
    wget http://www2.mmm.ucar.edu/wrf/OnLineTutorial/compile_tutorial/tar_files/mpich-3.0.4.tar.gz
fi
if [ ! -f "jasper-1.900.1.tar.gz" ]; then
    wget http://www2.mmm.ucar.edu/wrf/OnLineTutorial/compile_tutorial/tar_files/jasper-1.900.1.tar.gz
fi
if [ ! -f "libpng-1.2.50.tar.gz" ]; then
    wget http://www2.mmm.ucar.edu/wrf/OnLineTutorial/compile_tutorial/tar_files/libpng-1.2.50.tar.gz
fi
if [ ! -f "zlib-1.2.7.tar.gz" ]; then
    wget http://www2.mmm.ucar.edu/wrf/OnLineTutorial/compile_tutorial/tar_files/zlib-1.2.7.tar.gz
fi
export DIR=$(pwd)
echo Current directory $DIR
export CC=gcc
export CXX=g++
export FC=gfortran
export FCFLAGS=-m64
export F77=gfortran
export FFLAGS=-m64
module load Intel intel-para
if [[ ! -d "netcdf-4.1.3" ]]; then #proof, if netcdf is untared by testing, if "netcdf" is there
    tar -xzf netcdf-4.1.3.tar.gz     #or just .tar if no .gz present
    cd netcdf-4.1.3
    echo Installing NETCDF
    ./configure --prefix=$DIR/netcdf --disable-dap --disable-netcdf-4 --disable-shared
    make
    make install
    export PATH=$DIR/netcdf/bin:$PATH #correct it
    export NETCDF=$DIR/netcdf #correct it
    echo PATH: $PATH
    echo Successfully installed NETCDF
    cd ..
fi
if [[ ! -d "mpich-3.0.4" ]]; then #proof, if netcdf is untared by testing, if "mpich" is there
    tar -xzf mpich-3.0.4.tar.gz
    cd mpich-3.0.4
    echo Installing MPICH
    ./configure --prefix=$DIR/mpich
    make
    make install
    export PATH=$DIR/mpich/bin:$PATH
    cd ..
    echo Successfully installed MPICH
fi
if [[ ! -d "zlib-1.2.7" ]]; then #proof, if netcdf is untared by testing, if "zlib-1.2.7" is there
    echo Installing ZLIB
    export JASPERLIB=$DIR/grib2/lib 
    export JASPERINC=$DIR/grib2/include 
    tar -xzf zlib-1.2.7.tar.gz
    cd zlib-1.2.7
    ./configure --prefix=$DIR/grib2
    make
    make install
    cd ..
    echo Successfully installed ZLIB
fi
if [[ -d "libpng-1.2.50" ]]; then #proof, if netcdf is untared by testing, if "libpng-1.2.50" is there
    echo Installing LIBPNG
    tar -xzf libpng-1.2.50.tar.gz
    cd libpng-1.2.50
    ./configure --prefix=$DIR/grib2
    make
    make install
    cd ..
    echo Successfully installed LIBPNG
fi
if [[ ! -d "jasper-1.900.1" ]]; then #proof, if netcdf is untared by testing, if "jasper-1.900.1" is there
    echo Installing JASPER
    tar -xzf jasper-1.900.1.tar.gz
    cd jasper-1.900.1
    ./configure --prefix=$DIR/grib2
    make
    make install
    cd ..
    echo Successfully installed JASPER
fi
cd ../../$WRFdir
echo Current directory:
pwd
# WRF compilation
echo Configure WRF installation.
#load correct environment
export WRFIO_NCD_NO_LARGE_FILE_SUPPORT=1
export NETCDF=/usr/local/software/jureca/Stages/2019a/software/netCDF-Fortran/4.4.5-ipsmpi-2019a
export HDF5=/usr/local/software/jureca/Stages/2019a/software/HDF5/1.10.5-ipsmpi-2019a
###
cd main
echo FILES IN main:
ls
if [ -f "ndown.exe" -a -f "real.exe" -a -f "tc.exe" -a -f "wrf.exe" ]; then
    echo Execute files already exist!
    cd ..
else
    module load Intel intel-para netCDF-Fortran #load neccessary modules
    export NETCDF_classic=1 #option neccessary for WRF 4 versions (if it does not work with other versions, comment it out!
    cd ..
    ./clean -a
    ./configure #options
    echo Compiling starts. Look into "$project/$WRFdir/compile.log" to see, if it works or which errors happend
    ./compile em_real >& compile.log
fi
echo Existing execute files:
cd main
ls *.exe*
if [ ! -f "ndown.exe" ]; then
    echo Execute file "ndown.exe" not built! Abort.
    exit
fi
if [ ! -f "real.exe" ]; then
    echo Execute file "real.exe" not built! Abort.
    exit
fi
if [ ! -f "tc.exe" ]; then
    echo Execute file "tc.exe" not built! Abort.
    exit
fi
if [ ! -f "wrf.exe" ]; then
    echo Execute file "wrf.exe" not built! Abort.
    exit
fi
echo "###########################"
echo SUCCESSFULLY INSTALLED WRF!
echo "###########################"
echo ' '
echo Start of installation of WPS
cd ../..
mv $WRFdir WRFV3 #change name; otherwise the compiler of WPS cannot find the WRF diectory
cd $WPSdir
###
if [ -f "geogrid.exe" -a -f "ungrib.exe" -a -f "metgrid.exe" ]; then
    echo Execute files already exist!
else
    echo Installation of WPS started!
    #load correct environment
    export WRFIO_NCD_NO_LARGE_FILE_SUPPORT=1
    export NETCDF=/usr/local/software/jureca/Stages/2019a/software/netCDF-Fortran/4.4.5-ipsmpi-2019a
    export HDF5=/usr/local/software/jureca/Stages/2019a/software/HDF5/1.10.5-ipsmpi-2019a
    export JASPERLIB=$userdirectory/$project/$WPSdir/LIBRARIES/grib2/lib
    export JASPERINC=$userdirectory/$project/$WPSdir/LIBRARIES/grib2/include
    module load Intel intel-para netCDF-Fortran
    export NETCDF_classic=1 #option neccessary for WRF 4 versions (if it does not work with other versions, comment it out!
    ./clean -a
    ./configure
    echo WPS installation configured.
    echo Now compile WPS. Log file: $project/$WPSdir/compile.log
    ./compile >& compile.log
fi
mv $userdirectory/$project/WRFV3 $userdirectory/$project/$WRFdir
if [ ! -f "metgrid.exe" ]; then
    echo Execute file "metgrid.exe" not built! Abort.
    exit
fi
if [ ! -f "ungrib.exe" ]; then
    echo Execute file "ungrib.exe" not built! Abort.
    exit
fi
if [ ! -f "geogrid.exe" ]; then
    echo Execute file "geogrid.exe" not built! Abort.
    exit
fi
cd .. #go back to project directory
#rename the WRF directory, such that it is found by the WPS compiler.
echo '##########################'
echo SUCCESSFULLY INSTALLED WPS!
echo '##########################'
echo ' '
echo Making neccessary directories to use WRF and copy directory of wrfrun, namelist and .in files into project directory.
if [ ! -d "MET" ]; then
    mkdir MET
fi
if [ ! -d "SRC" ]; then
    mkdir SRC
fi
cd ..
if [ ! -d $project/scripts ]; then
    mv wrfscripts $project/scripts
fi
if [ ! -d "WRF" ]; then
    mkdir WRF
fi
cd WRF
if [ ! -d "TAR" ]; then
    mkdir TAR
fi
echo Compress build WRF and WPS version and copy them into the TAR and SRC directory.
if [ ! -f $userdirectory/WRF/TAR/WRFV$version-$platform.tar ]; then
    cd $userdirectory/$project/WRFV$version
    tar -czf WRFV$version-$platform.tar *
    mv WRFV$version-$platform.tar $userdirectory/WRF/TAR
fi
if [ ! -f $userdirectory/WRF/TAR/WPSV$version-$platform.tar ]; then
    cd $userdirectory/$project/WPSV$version
    tar -czf WPSV$version-$platform.tar *
    mv WPSV$version-$platform.tar $userdirectory/WRF/TAR
fi
cd $userdirectory/WRF/TAR
cp WRFV$version-$platform.tar ../../$project/SRC
cp WPSV$version-$platform.tar ../../$project/SRC
echo Make directories, where big data files are saved.
if [ ! -d "$scratchdir/METINPUT" ]; then
    mkdir $scratchdir/METINPUT
fi
if [ ! -d $scratchdir/$project ]; then
    mkdir $scratchdir/$project
fi
if [ ! -d $scratchdir/$project/MET ]; then
    mkdir $scratchdir/$project/MET
fi
if [ ! -d $scratchdir/$project/TMP ]; then
    mkdir $scratchdir/$project/TMP
fi
echo Installation finished successfully!!!
##
echo ' '
echo Change the following input variables "in" wrfrun_JURECA.ksh:
echo PLATFORM=$platform
echo WRFuser=$userdirectory/WRF
echo Version=V$version
echo runGEOGRID=yes "(because first run of WRF has to include geogrid)"
echo runWRF=no
echo ROOT_PATH=$userdirectory
echo WORK_ROOT=$scratchdir
echo DATA_ROOT=/arch/jicg21/$user
echo Choose new Episode parameters!
if [[ ${version:0:1} == "3" ]]; then
    echo GEOG_DATA=/p/project/cjicg21/jicg2119/WRF/DATA/geogV3.5_V3.6 "(if you use JURECA, otherwise you have to look for a geogrid data path on your platform or have to download a version from the WRF website, that is compatible with your WRF version)"
elif [[ ${version:0:1} == "4" ]]; then
    echo GEOG_DATA=/p/project/cjicg21/backes1/WRF/DATA/WPS_GEOG "(if you use JURECA, otherwise you have to look for a geogrid data path on your platform or have to download a version from the WRF website, that is compatible with your WRF version)"
else
    echo Download new geogrid data!
fi
echo Search "in" the /arch directory for MARS data and paste the path of the MARS directory for the METINPUT variable
echo Choose new Domain variables!
echo Choose the time steps "(DT)"! CFL criterium must be fulfilled! Suggestion: 6 seconds per km grid spacing "(DS)".
echo Choose COARSE GRID and MULTIPROCESSING variables "(suggestion: WORKERS=240)"
echo ' '
echo When you have changed these variables, test your WRF version by ./wrfrun_JURECA.ksh!
exit
